import React, { useState, useEffect } from 'react';
import { 
  AreaChart, Area, ResponsiveContainer 
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheck, Shield, Star, Plus, MoreHorizontal, 
  ArrowUpRight, Zap, CheckCircle2, 
  HelpCircle, ChevronDown, ExternalLink, Settings,
  Cpu, Database, Clock, ArrowRight, UserPlus, KeyRound,
  Terminal, Play, RefreshCw, CheckCircle, Info, ShieldAlert
} from 'lucide-react';
import { Service } from '../../types';

interface OverviewProps {
  setActiveTab: (tab: string) => void;
  setOpenNewProjectModal: (open: boolean) => void;
  setOpenInviteTeammateModal: (open: boolean) => void;
  setOpenNewMemoryModal: (open: boolean) => void;
  isDark: boolean;
  services: Service[];
}

// Sparkline Mock Data for the 3 upper cards
const securitySparklineData = [
  { val: 40 }, { val: 45 }, { val: 42 }, { val: 58 }, { val: 50 }, { val: 62 }, { val: 55 }, { val: 69 }
];

const performanceSparklineData = [
  { val: 10 }, { val: 15 }, { val: 8 }, { val: 12 }, { val: 30 }, { val: 14 }, { val: 18 }, { val: 45 }
];

const activitySparklineData = [
  { val: 30 }, { val: 32 }, { val: 28 }, { val: 35 }, { val: 40 }, { val: 38 }, { val: 42 }, { val: 48 }
];

export default function Overview({ 
  setActiveTab, 
  setOpenNewProjectModal, 
  setOpenInviteTeammateModal,
  services
}: OverviewProps) {
  const [activeLogTab, setActiveLogTab] = useState<'All' | 'Attestations' | 'Audit'>('All');
  
  // Interactive Simulator States
  const [selectedSimService, setSelectedSimService] = useState<string>(services[0]?.name || 'royal-driving-school');
  const [simStatus, setSimStatus] = useState<'idle' | 'running' | 'success' | 'failed'>('idle');
  const [simLogs, setSimLogs] = useState<string[]>([]);
  const [progressPercent, setProgressPercent] = useState<number>(0);

  // Hardcoded audit logs tailored for the secure enclaves app
  const auditLogs = [
    { id: '1', action: 'Attested Enclave Service', target: 'royal-driving-school', time: '11 days ago' },
    { id: '2', action: 'Issued attestation credentials', target: 'ZEXVRO-secure-tunnel', time: '12 days ago' },
    { id: '3', action: 'Provisioned Memory Key Block', target: 'All assets', time: '21 days ago' },
  ];

  const activeServicesCount = services.filter(s => s.status === 'active').length;

  // Simulator runner effect
  const handleRunAttestationChallenge = () => {
    if (simStatus === 'running') return;
    
    setSimStatus('running');
    setProgressPercent(0);
    setSimLogs([`[00:01] 📡 Initializing Remote Attestation challenge for: ${selectedSimService}`]);

    const logSteps = [
      { text: `[00:03] 🔒 Establishing secure ECDH (Diffie-Hellman) channel with Intel SGX CPU...`, progress: 20 },
      { text: `[00:05] 📂 Querying MRENCLAVE (Enclave measurement hash) and MRSIGNER...`, progress: 45 },
      { text: `[00:08] 🧬 Requesting cryptographically signed Quote from Platform Quoting Enclave...`, progress: 70 },
      { text: `[00:10] 🌐 Verification request dispatched to Intel Attestation Service (IAS)...`, progress: 85 },
      { text: `[00:12] ✅ Success! Hardware signature verified. Authority SVN levels checked.`, progress: 100 },
      { text: `[00:13] 🔑 Ephemeral encryption keys established. Enclave status set to 100% SECURED.`, progress: 100 }
    ];

    let stepIdx = 0;
    const interval = setInterval(() => {
      if (stepIdx < logSteps.length) {
        const nextStep = logSteps[stepIdx];
        setSimLogs(prev => [...prev, nextStep.text]);
        setProgressPercent(nextStep.progress);
        stepIdx++;
      } else {
        clearInterval(interval);
        setSimStatus('success');
      }
    }, 1000);
  };

  return (
    <div className="space-y-6 text-zinc-300 font-sans">
      
      {/* Account Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <span className="text-[11px] font-sans font-semibold tracking-wide uppercase text-zinc-500">Account Home</span>
          <h1 className="text-2xl sm:text-3xl font-medium tracking-tight text-white mt-1">
            kulkarniparis01@gmail.com's Account
          </h1>
        </div>
        
        {/* Actions Button Group */}
        <div className="flex items-center gap-2 self-start sm:self-center shrink-0 font-sans text-xs">
          <button className="p-2.5 rounded bg-zinc-950 hover:bg-zinc-900 border border-zinc-900 text-zinc-400 hover:text-white transition-all cursor-pointer" title="Favorites">
            <Star className="h-4 w-4" />
          </button>
          <button className="p-2.5 rounded bg-zinc-950 hover:bg-zinc-900 border border-zinc-900 text-zinc-400 hover:text-white transition-all cursor-pointer" title="Menu">
            <MoreHorizontal className="h-4 w-4" />
          </button>
          <button 
            onClick={() => setOpenNewProjectModal(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs transition-all cursor-pointer shadow-md shadow-blue-900/10"
          >
            <Plus className="h-4 w-4" />
            <span>Add Service</span>
          </button>
        </div>
      </div>

      {/* Analytics Subtitle Row */}
      <div className="flex items-center justify-between pt-2.5 border-t border-zinc-900">
        <h2 className="text-xs font-semibold text-zinc-400 tracking-wide uppercase font-sans">
          Security & Operational Metrics
        </h2>
        <div className="flex items-center gap-1.5 text-xs text-zinc-400 bg-zinc-950 border border-zinc-900 px-3 py-1.5 rounded-md cursor-pointer hover:text-white transition-all font-sans">
          <span>Last 24 hours</span>
          <ChevronDown className="h-3.5 w-3.5" />
        </div>
      </div>

      {/* 1. UPPER CARDS GRID (Security, Performance, Activity) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Card 1: Active Cryptographic Enclaves */}
        <div className="p-5 rounded-lg border border-zinc-900 bg-[#09090b] flex flex-col justify-between h-[165px] relative overflow-hidden group hover:border-zinc-800 transition-all">
          <div className="flex items-center gap-1.5 text-zinc-400 text-xs font-semibold font-sans border-b border-zinc-900/50 pb-2.5">
            <Cpu className="h-4 w-4 text-blue-500" />
            <span>Active Enclaves</span>
          </div>

          <div className="grid grid-cols-2 gap-4 my-2 z-10">
            <div>
              <span className="text-[10px] text-zinc-500 flex items-center gap-1 font-sans">
                Total Registered <HelpCircle className="h-2.5 w-2.5" />
              </span>
              <div className="mt-1 flex items-baseline gap-1.5">
                <span className="text-2xl font-bold text-white font-sans tracking-tight">{services.length}</span>
                <span className="text-[10px] text-emerald-500 font-sans font-medium">100% Attested</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] text-zinc-500 flex items-center gap-1 font-sans">
                Running Services
              </span>
              <div className="mt-1">
                <span className="text-xl font-bold text-white font-sans tracking-tight">{activeServicesCount} / {services.length}</span>
              </div>
            </div>
          </div>

          {/* Sparkline line container in bottom right */}
          <div className="absolute bottom-0 right-0 left-1/2 h-[50px] w-1/2 opacity-60 pointer-events-none group-hover:opacity-85 transition-opacity">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={securitySparklineData} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="secGlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="val" stroke="#3B82F6" strokeWidth={1.5} fill="url(#secGlow)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Card 2: Secure Memory Performance */}
        <div className="p-5 rounded-lg border border-zinc-900 bg-[#09090b] flex flex-col justify-between h-[165px] relative overflow-hidden group hover:border-zinc-800 transition-all">
          <div className="flex items-center gap-1.5 text-zinc-400 text-xs font-semibold font-sans border-b border-zinc-900/50 pb-2.5">
            <Database className="h-4 w-4 text-amber-500" />
            <span>Secure Memory Blocks</span>
          </div>

          <div className="grid grid-cols-2 gap-4 my-2 z-10">
            <div>
              <span className="text-[10px] text-zinc-500 flex items-center gap-1 font-sans">
                Attested Memory <HelpCircle className="h-2.5 w-2.5" />
              </span>
              <div className="mt-1 flex items-baseline gap-1.5">
                <span className="text-2xl font-bold text-white font-sans tracking-tight">3.8 MB</span>
                <span className="text-[10px] text-zinc-400 font-sans">75% Usage</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] text-zinc-500 flex items-center gap-1 font-sans">
                Avg Proof Gen
              </span>
              <div className="mt-1">
                <span className="text-xl font-bold text-white font-sans tracking-tight">242 <span className="text-xs text-zinc-500 font-normal">ms</span></span>
              </div>
            </div>
          </div>

          {/* Sparkline line container in bottom right */}
          <div className="absolute bottom-0 right-0 left-1/2 h-[50px] w-1/2 opacity-60 pointer-events-none group-hover:opacity-85 transition-opacity">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={performanceSparklineData} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="perfGlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#F59E0B" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="val" stroke="#F59E0B" strokeWidth={1.5} fill="url(#perfGlow)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Card 3: Network Operations & Tunnels */}
        <div className="p-5 rounded-lg border border-zinc-900 bg-[#09090b] flex flex-col justify-between h-[165px] relative overflow-hidden group hover:border-zinc-800 transition-all">
          <div className="flex items-center gap-1.5 text-zinc-400 text-xs font-semibold font-sans border-b border-zinc-900/50 pb-2.5">
            <Zap className="h-4 w-4 text-emerald-500" />
            <span>Secure Tunnel Operations</span>
          </div>

          <div className="grid grid-cols-2 gap-4 my-2 z-10">
            <div>
              <span className="text-[10px] text-zinc-500 flex items-center gap-1 font-sans">
                Active Connections <HelpCircle className="h-2.5 w-2.5" />
              </span>
              <div className="mt-1 flex items-baseline gap-1.5">
                <span className="text-2xl font-bold text-white font-sans tracking-tight">1,480</span>
                <span className="text-[10px] text-emerald-500 font-sans font-medium">Normal</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] text-zinc-500 flex items-center gap-1 font-sans">
                Sync Latency
              </span>
              <div className="mt-1">
                <span className="text-xl font-bold text-white font-sans tracking-tight">12 <span className="text-xs text-zinc-500 font-normal">ms</span></span>
              </div>
            </div>
          </div>

          {/* Sparkline line container in bottom right */}
          <div className="absolute bottom-0 right-0 left-1/2 h-[50px] w-1/2 opacity-60 pointer-events-none group-hover:opacity-85 transition-opacity">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activitySparklineData} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="actGlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="val" stroke="#10B981" strokeWidth={1.5} fill="url(#actGlow)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* 2. CORE ENCLAVES LISTING & REAL-TIME ATTENTATION CHALLENGER (SUPER SENSIBLE SECTION) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Real Registered Enclaves Panel (Span 6) */}
        <div className="lg:col-span-6 p-5 rounded-lg border border-zinc-900 bg-[#09090b] flex flex-col justify-between min-h-[350px]">
          <div>
            <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-white font-sans">Cryptographic Workspace Enclaves</span>
                <span className="px-2 py-0.5 rounded-full bg-zinc-800 text-[10px] font-bold text-zinc-300 font-sans">{services.length}</span>
              </div>
              <button 
                onClick={() => setActiveTab('services')}
                className="text-[10px] font-sans font-medium text-blue-500 hover:text-blue-400 cursor-pointer flex items-center gap-1.5 transition-colors"
              >
                Go to Portal <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* List */}
            <div className="space-y-2 mt-4 max-h-[250px] overflow-y-auto pr-1">
              {services.map((svc) => (
                <div 
                  key={svc.id}
                  onClick={() => {
                    setSelectedSimService(svc.name);
                    setSimStatus('idle');
                    setSimLogs([]);
                  }}
                  className={`flex items-center justify-between p-3 rounded-md border transition-all cursor-pointer group text-xs ${
                    selectedSimService === svc.name 
                      ? 'bg-zinc-900/40 border-zinc-700 text-white' 
                      : 'bg-zinc-950/40 border-zinc-900 hover:border-zinc-800 text-zinc-300'
                  }`}
                  title="Select for Remote Attestation testing"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <span className={`p-1.5 rounded bg-zinc-900 border border-zinc-800 shrink-0 ${
                      selectedSimService === svc.name ? 'text-blue-500' : 'text-zinc-500'
                    }`}>
                      <Cpu className="h-4 w-4" />
                    </span>
                    <div className="min-w-0">
                      <p className="font-semibold truncate font-sans text-white">{svc.name}</p>
                      <p className="text-[10px] text-zinc-500 truncate mt-0.5">Category: {svc.category || 'secure'} • Updated: {svc.lastActivity || 'recently'}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0 font-sans text-[10px]">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold border uppercase tracking-wider ${
                      svc.status === 'active' 
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                        : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                    }`}>
                      {svc.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-zinc-900/60 mt-4 flex justify-between items-center text-[10px] text-zinc-500 font-sans">
            <span>Enclave Security Score: 100/100</span>
            <span>Click any Enclave to challenge signature</span>
          </div>
        </div>

        {/* Real-time Intel SGX Attestation Challenger (Span 6) - BREATHE REAL OPERATION */}
        <div className="lg:col-span-6 p-5 rounded-lg border border-zinc-900 bg-[#09090b] flex flex-col justify-between min-h-[350px]">
          <div>
            <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
              <div className="flex items-center gap-2">
                <Terminal className="h-4 w-4 text-brand-purple" />
                <span className="text-xs font-semibold text-white font-sans">Enclave Attestation Sandbox</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-brand-blue/15 text-brand-blue border border-brand-blue/20 text-[9px] font-sans uppercase font-bold">
                Intel SGX Emulator
              </span>
            </div>

            {/* Quick configuration description */}
            <div className="mt-3.5 flex items-center justify-between bg-zinc-950/60 border border-zinc-900 p-2.5 rounded-md text-xs">
              <div className="flex items-center gap-2">
                <Info className="h-4 w-4 text-zinc-500 shrink-0" />
                <span className="text-zinc-400 font-sans">
                  Target: <strong className="font-mono text-white">{selectedSimService}</strong>
                </span>
              </div>
              <span className="text-[10px] text-zinc-500 font-sans">Local Host</span>
            </div>

            {/* Terminal Window */}
            <div className="mt-3 bg-black border border-zinc-900 rounded-md p-3 h-[180px] overflow-y-auto font-mono text-[10.5px] text-emerald-400/90 space-y-1.5 scrollbar-thin">
              {simLogs.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-zinc-600 font-sans py-4 space-y-2">
                  <Terminal className="h-8 w-8 text-zinc-700" />
                  <div>
                    <p className="text-xs font-semibold">Sandbox Console Ready</p>
                    <p className="text-[10px] mt-0.5">Click "Run Attestation" below to verify cryptographic quote integrity.</p>
                  </div>
                </div>
              ) : (
                <>
                  {simLogs.map((log, i) => (
                    <div key={i} className="leading-relaxed whitespace-pre-wrap break-all border-l-2 border-emerald-950/50 pl-2">
                      {log}
                    </div>
                  ))}
                  {simStatus === 'running' && (
                    <div className="flex items-center gap-2 text-zinc-400 animate-pulse mt-1 pl-2">
                      <RefreshCw className="h-3 w-3 animate-spin text-brand-purple" />
                      <span>Reading SGX Registers...</span>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Action Row */}
          <div className="pt-3 border-t border-zinc-900 mt-4 flex items-center justify-between gap-4">
            {/* Progress Bar */}
            <div className="flex-1">
              <div className="flex items-center justify-between text-[10px] text-zinc-500 font-sans mb-1">
                <span>Verification State</span>
                <span>{progressPercent}%</span>
              </div>
              <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-brand-blue transition-all duration-300" 
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            <button
              onClick={handleRunAttestationChallenge}
              disabled={simStatus === 'running'}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded text-xs font-semibold tracking-wide transition-all cursor-pointer select-none shrink-0 ${
                simStatus === 'running'
                  ? 'bg-zinc-800 text-zinc-500 border border-zinc-700 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-900/10'
              }`}
            >
              {simStatus === 'running' ? (
                <>
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  <span>Verifying...</span>
                </>
              ) : (
                <>
                  <Play className="h-3.5 w-3.5" />
                  <span>Run Attestation</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>

      {/* 3. LOWER ROW GRID (Audit Logs & Team Access Guidelines) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* AUDIT LOGS (Column Span 7) */}
        <div className="lg:col-span-7 p-5 rounded-lg border border-zinc-900 bg-[#09090b] flex flex-col justify-between min-h-[220px]">
          <div>
            <div className="flex items-center justify-between border-b border-zinc-900 pb-2.5">
              <span className="text-xs font-semibold text-white font-sans">Real-time SecOps Audit Trail</span>
              <button onClick={() => setActiveTab('security')} className="text-zinc-500 hover:text-zinc-300 transition-colors">
                <ExternalLink className="h-4 w-4" />
              </button>
            </div>

            {/* Sub Tabs */}
            <div className="flex items-center gap-3 border-b border-zinc-900/40 py-2 text-[11px] font-sans">
              {(['All', 'Attestations', 'Audit'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveLogTab(tab)}
                  className={`px-1 py-0.5 relative transition-colors cursor-pointer ${
                    activeLogTab === tab ? 'text-blue-500 font-bold' : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  {tab}
                  {activeLogTab === tab && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500 rounded-full" />
                  )}
                </button>
              ))}
            </div>

            {/* Log Rows */}
            <div className="space-y-2 mt-3 font-mono text-[11px]">
              {auditLogs.map((log) => (
                <div key={log.id} className="flex items-center justify-between py-1.5 border-b border-zinc-900/30 text-zinc-400 hover:text-white transition-all">
                  <div className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-blue-500/80" />
                    <span className="text-zinc-200">{log.action}</span>
                    <span className="text-zinc-600">•</span>
                    <span className="text-zinc-500">{log.target}</span>
                  </div>
                  <span className="text-zinc-600 shrink-0">{log.time}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end border-t border-zinc-900/60 mt-4">
            <span onClick={() => setActiveTab('security')} className="text-[10px] font-sans text-zinc-500 hover:text-zinc-300 transition-colors cursor-pointer">
              View full security audit history →
            </span>
          </div>
        </div>

        {/* REGIONAL HEALTH (Column Span 5) */}
        <div className="lg:col-span-5 p-5 rounded-lg border border-zinc-900 bg-[#09090b] flex flex-col justify-between min-h-[220px]">
          <div>
            <h3 className="text-xs font-sans font-bold uppercase tracking-wide text-zinc-400 dark:text-zinc-500 mb-1">
              Regional Health & Attestation Nodes
            </h3>
            <span className="text-[10px] text-zinc-500 font-sans">Global Intel SGX Regions</span>
          </div>

          {/* Abstract stylized world map dot SVG representation for hyper-polished display */}
          <div className="my-2 flex items-center justify-center">
            <svg viewBox="0 0 200 80" className="w-full h-16 opacity-30 dark:opacity-40 text-zinc-400 dark:text-zinc-600" fill="currentColor">
              {/* Stylized dots representing continents */}
              <circle cx="25" cy="25" r="3" />
              <circle cx="35" cy="30" r="2.5" />
              <circle cx="45" cy="40" r="2" />
              <circle cx="30" cy="45" r="3" />
              {/* Europe & Africa */}
              <circle cx="90" cy="20" r="3" />
              <circle cx="100" cy="25" r="2" />
              <circle cx="95" cy="45" r="3" />
              <circle cx="102" cy="55" r="2.5" />
              {/* Asia & Oceania */}
              <circle cx="140" cy="22" r="3.5" />
              <circle cx="155" cy="28" r="3" />
              <circle cx="165" cy="38" r="2.5" />
              <circle cx="150" cy="45" r="2" />
              <circle cx="170" cy="60" r="3" />
              {/* Visual global connection lines */}
              <path d="M 35 30 Q 90 20 140 22" fill="none" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2 2" />
              <path d="M 30 45 Q 95 45 150 45" fill="none" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2 2" />
            </svg>
          </div>

          {/* Regional details bullet list */}
          <div className="space-y-1.5 pt-2 border-t border-zinc-900/50">
            <div className="flex items-center gap-2 text-xs text-zinc-450 dark:text-zinc-400">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
              <span className="font-sans">N. America SGX Node Pool - Active</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-zinc-450 dark:text-zinc-400">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
              <span className="font-sans">Europe SGX Node Pool - Active</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-zinc-450 dark:text-zinc-400">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="font-sans font-medium text-zinc-800 dark:text-zinc-250">Asia Pacific - Active & Attested</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
