import { Project, Deployment, Service, TeamMember, CollaborationNote, MemoryEntry, AuditLog, SecurityKey } from '../types';

export const mockProjects: Project[] = [
  {
    id: 'proj-1',
    name: 'zk-vault-gateway',
    status: 'active',
    serviceUsage: ['Zero-Knowledge Privacy Pool', 'Captch-like Agent Authentication Service'],
    region: 'us-east-1 (Stellar Testnet)',
    network: 'Stellar Testnet',
    lastDeployment: '2026-07-05 18:34',
    owner: 'paris-29',
    branch: 'main',
    framework: 'React + Node'
  },
  {
    id: 'proj-2',
    name: 'trade-nexus-pipeline',
    status: 'active',
    serviceUsage: ['A-2-A Trade Pipeline', 'Transformation Agent'],
    region: 'eu-west-1 (Stellar Testnet)',
    network: 'Stellar Testnet',
    lastDeployment: '2026-07-04 12:15',
    owner: 'Wraient',
    branch: 'release/v2',
    framework: 'Go + Python'
  },
  {
    id: 'proj-3',
    name: 'depin-mesh-node',
    status: 'deploying',
    serviceUsage: ['De-pin', 'Transformation Agent'],
    region: 'ap-southeast-1 (Stellar Testnet)',
    network: 'Stellar Testnet',
    lastDeployment: '2026-07-05 21:50',
    owner: 'n4bi10p',
    branch: 'dev-mesh',
    framework: 'Rust + WASM'
  },
  {
    id: 'proj-4',
    name: 'stellar-nft-marketplace',
    status: 'failed',
    serviceUsage: ['NFT Service'],
    region: 'us-west-2 (Stellar Testnet)',
    network: 'Stellar Testnet',
    lastDeployment: '2026-07-03 09:40',
    owner: 'paris-29',
    branch: 'main',
    framework: 'Next.js'
  }
];

export const mockDeployments: Deployment[] = [
  {
    id: 'dep-101',
    projectName: 'depin-mesh-node',
    commitHash: '8f2c3da',
    commitMessage: 'fix(mesh): resolve connection handshake timeout on Stellar testnet socket',
    status: 'Building',
    timestamp: '2026-07-05 21:50',
    duration: '1m 45s (Running)',
    author: 'n4bi10p',
    logs: [
      '[05:01:12] [BUILD] Initializing Rust cargo build container...',
      '[05:01:15] [BUILD] Fetching dependencies (stellar-sdk, tokio, serde)...',
      '[05:01:25] [BUILD] Compiling depin-mesh-node v0.4.1...',
      '[05:01:55] [BUILD] Optimizing WASM target binary with wasm-opt...',
      '[05:02:10] [BUILD] Building client bundles using Vite v6...',
      '[05:02:12] [SYSTEM] Scanning built image for known vulnerabilities...',
      '[05:02:14] [SYSTEM] Found 0 critical vulnerabilities. Proceeding to verify phase...',
      '[05:02:15] [VERIFY] Initiating cryptographically secure binary handshake test...',
      '[05:02:16] [VERIFY] Executing 14 unit test suites on Stellar Testnet sandbox...',
      '[05:02:17] [VERIFY] Test suite A: Passed (12 tests)',
      '[05:02:18] [VERIFY] Test suite B (Privacy check): Passed (4 tests)',
      '[05:02:20] [VERIFY] Waiting for network orchestration verify...'
    ]
  },
  {
    id: 'dep-100',
    projectName: 'zk-vault-gateway',
    commitHash: 'a4b8c9d',
    commitMessage: 'feat(zk): implement batch credential generation inside the privacy pool',
    status: 'Live',
    timestamp: '2026-07-05 18:34',
    duration: '2m 15s',
    author: 'paris-29',
    logs: [
      '[18:32:00] [BUILD] Initializing Node image build...',
      '[18:32:15] [BUILD] Injecting secure environment variables inside enclave...',
      '[18:32:30] [BUILD] Bundling app with Rollup...',
      '[18:33:10] [VERIFY] Running ZK proof constraints checker...',
      '[18:33:30] [VERIFY] Proof generation validated successfully (1024-bit key-pair)',
      '[18:33:45] [DEPLOY] Provisioning container in secure isolated enclave...',
      '[18:34:00] [DEPLOY] Hot-swapping routing nodes at ingress proxy...',
      '[18:34:10] [MONITOR] Gateway health check: 200 OK',
      '[18:34:15] [SYSTEM] Deployment live on Stellar Testnet!'
    ]
  },
  {
    id: 'dep-99',
    projectName: 'trade-nexus-pipeline',
    commitHash: '3f9e0a1',
    commitMessage: 'refactor(trade): optimize agent arbitrage pricing path and limit controls',
    status: 'Live',
    timestamp: '2026-07-04 12:15',
    duration: '1m 58s',
    author: 'Wraient',
    logs: [
      '[12:13:00] [BUILD] Initializing Go container compile...',
      '[12:13:40] [VERIFY] Simulating 10,000 high-frequency A-2-A requests on mock Stellar DEX...',
      '[12:14:20] [VERIFY] Trade risk limits verified: no margin breaches detected',
      '[12:14:40] [DEPLOY] Pushing build image to container register...',
      '[12:15:00] [DEPLOY] Scaling up trade replica sets (3 nodes)...',
      '[12:15:15] [SYSTEM] Ingress routing switched. Release Live!'
    ]
  },
  {
    id: 'dep-98',
    projectName: 'stellar-nft-marketplace',
    commitHash: 'cf9922b',
    commitMessage: 'chore: update stellar asset contract addresses for NFT minting',
    status: 'Failed',
    timestamp: '2026-07-03 09:40',
    duration: '45s',
    author: 'paris-29',
    logs: [
      '[09:39:10] [BUILD] Initializing Web compilation...',
      '[09:39:25] [BUILD] Compiling page assets...',
      '[09:39:40] [VERIFY] Verifying Stellar smart contract ABI binding...',
      '[09:39:50] [ERROR] InvalidContractAddressException: Address GCKI3... does not exist on Stellar Testnet',
      '[09:39:52] [ERROR] Verify phase failed. Deployment aborted.',
      '[09:39:55] [SYSTEM] Retained active deployment (dep-97) live.'
    ]
  }
];

export const mockServices: Service[] = [
  {
    id: 'srv-1',
    name: 'Zero-Knowledge Privacy Pool',
    owner: 'paris-29',
    status: 'active',
    description: 'Privacy-preserving zero-knowledge pool for credential and state hiding.',
    progress: 100,
    lastActivity: '12 mins ago',
    category: 'privacy'
  },
  {
    id: 'srv-2',
    name: 'Transformation Agent',
    owner: 'Wraient',
    status: 'active',
    description: 'Agentic code and environment scan for automatic vulnerability remediation.',
    progress: 80,
    lastActivity: '1 hour ago',
    category: 'transformation'
  },
  {
    id: 'srv-3',
    name: 'A-2-A Trade Pipeline',
    owner: 'Wraient',
    status: 'active',
    description: 'Autonomous agent-to-agent trading infrastructure with customizable smart limits.',
    progress: 100,
    lastActivity: '4 hours ago',
    category: 'trade'
  },
  {
    id: 'srv-4',
    name: 'Captch-like Agent Authentication Service',
    owner: 'n4bi10p',
    status: 'configuring',
    description: 'Proof of human vs. agent cryptographic challenges to defend autonomous APIs.',
    progress: 40,
    lastActivity: 'Yesterday',
    category: 'auth'
  },
  {
    id: 'srv-5',
    name: 'NFT Service',
    owner: 'paris-29',
    status: 'inactive',
    description: 'Decentralized metadata and digital collectible token lifecycle tooling.',
    progress: 0,
    lastActivity: '3 days ago',
    category: 'nft'
  },
  {
    id: 'srv-6',
    name: 'De-pin',
    owner: 'n4bi10p',
    status: 'configuring',
    description: 'Decentralized physical infrastructure network orchestration and node telemetry tracking.',
    progress: 60,
    lastActivity: '2 hours ago',
    category: 'depin'
  }
];

export const mockTeamMembers: TeamMember[] = [
  {
    id: 'team-1',
    name: 'Paris',
    alias: 'paris-29',
    email: 'kulkarniparis01@gmail.com',
    role: 'Owner',
    status: 'active',
    lastActive: 'Just now',
    servicesOwned: ['Zero-Knowledge Privacy Pool', 'NFT Service']
  },
  {
    id: 'team-2',
    name: 'Rushi',
    alias: 'Wraient',
    email: 'rushi@zexvro.io',
    role: 'Admin',
    status: 'active',
    lastActive: '12 mins ago',
    servicesOwned: ['A-2-A Trade Pipeline', 'Transformation Agent']
  },
  {
    id: 'team-3',
    name: 'Nabil',
    alias: 'n4bi10p',
    email: 'nabil@zexvro.io',
    role: 'Developer',
    status: 'active',
    lastActive: '2 hours ago',
    servicesOwned: ['De-pin', 'Captch-like Agent Authentication Service']
  },
  {
    id: 'team-4',
    name: 'Guardian Agent v1',
    alias: 'guardian-ai',
    email: 'agent-guardian@zexvro.io',
    role: 'Agent',
    status: 'active',
    lastActive: '1 sec ago',
    servicesOwned: ['Transformation Agent']
  }
];

export const mockCollaborationNotes: CollaborationNote[] = [
  {
    id: 'note-1',
    author: 'paris-29',
    timestamp: '2026-07-05 18:45',
    currentState: 'The ZK Privacy Pool is integrated with the main gateway in project zk-vault-gateway. Enclave testing shows 100% cryptographic compatibility.',
    nextStep: 'Deploy validation enclaves to Stellar Testnet and generate the operational keys.',
    filesToInspect: ['src/enclaves/zk-proof.ts', 'src/enclaves/keys.json'],
    doNotTouch: ['src/enclaves/curves.wasm'],
    ownerNeeded: 'n4bi10p'
  },
  {
    id: 'note-2',
    author: 'Wraient',
    timestamp: '2026-07-04 15:30',
    currentState: 'A-2-A Trade Pipeline smart limit guards are verified against simulated flash loan crashes.',
    nextStep: 'Connect the telemetry output from the Stellar DEX node into De-pin metrics dashboard.',
    filesToInspect: ['src/trade/limit-guards.go', 'src/trade/metrics-stream.py'],
    doNotTouch: ['src/trade/core-orderbook.go'],
    ownerNeeded: 'Wraient'
  }
];

export const mockMemoryEntries: MemoryEntry[] = [
  {
    id: 'mem-1',
    service: 'Zero-Knowledge Privacy Pool',
    filesChanged: ['src/enclaves/curves.wasm', 'src/enclaves/zk-proof.ts'],
    summary: 'Locked in the pairing-friendly curve constants for Stellar-compatible proving. Standardized proving engine v2.',
    decisions: [
      'Use BN254 curve over BLS12-381 for 40% faster on-chain validation',
      'Store proofs in high-throughput local memory cache with TTL of 5 mins'
    ],
    followUps: [
      'Verify proof size constraints under extreme batch load (100+ parallel tx)',
      'Connect the Captch-like agent auth challenge as pre-proving guard'
    ],
    blockers: [],
    verification: 'Executed proving simulation on 10,000 enclaves with zero proof collisions.',
    date: '2026-07-05 19:10',
    owner: 'paris-29',
    label: 'decision'
  },
  {
    id: 'mem-2',
    service: 'Transformation Agent',
    filesChanged: ['src/security/enclave-policy.json'],
    summary: 'The code vulnerability scanner identified risk in stellar-nft-marketplace. Codebase was corrected and locked.',
    decisions: [
      'Forbid dynamic import lines in Web3 contracts unless verified by Agent',
      'Auto-rollback deployment if any key exposure is detected during build phase'
    ],
    followUps: [
      'Implement real-time alert trigger to Slack and Discord on policy breaches'
    ],
    blockers: [
      'Missing deep Stellar Testnet contract registry list. Blocked from offline smart contract validation'
    ],
    verification: 'Successfully ran vulnerability scanning against 4 local projects; detected and resolved 1 high-risk variable leak.',
    date: '2026-07-05 11:30',
    owner: 'Wraient',
    label: 'blocker'
  },
  {
    id: 'mem-3',
    service: 'A-2-A Trade Pipeline',
    filesChanged: ['src/trade/limit-guards.go'],
    summary: 'Standardized handoff metrics for agent-to-agent trading pipelines. Active limit guards successfully prevent orderbook manipulation.',
    decisions: [
      'Limit high-frequency orders to maximum of 50 tx per minute per agent identity',
      'Strictly use G-address cryptosignatures for authentication'
    ],
    followUps: [
      'Upgrade arbitrage algorithm to factor in transient DEX fees',
      'Align database storage for order history'
    ],
    blockers: [],
    verification: 'Wrote orders mock simulation; limit guards successfully rejected out-of-bounds prices in 100% of test runs.',
    date: '2026-07-04 14:02',
    owner: 'Wraient',
    label: 'handoff'
  }
];

export const mockAuditLogs: AuditLog[] = [
  {
    id: 'log-1001',
    timestamp: '2026-07-05 21:55',
    actor: 'n4bi10p',
    action: 'DEPLOY_PROJECT_START',
    target: 'depin-mesh-node (release/v2)',
    status: 'success',
    ip: '198.162.4.29'
  },
  {
    id: 'log-1000',
    timestamp: '2026-07-05 21:48',
    actor: 'Wraient',
    action: 'CREATE_API_KEY',
    target: 'Agent-Scan-Read-Key',
    status: 'success',
    ip: '102.15.22.140'
  },
  {
    id: 'log-999',
    timestamp: '2026-07-05 19:22',
    actor: 'paris-29',
    action: 'UPDATE_MEMORIZED_DECISION',
    target: 'Zero-Knowledge Privacy Pool',
    status: 'success',
    ip: '203.0.113.82'
  },
  {
    id: 'log-998',
    timestamp: '2026-07-05 18:30',
    actor: 'system',
    action: 'AUTO_RECOVERY_ROLLBACK',
    target: 'stellar-nft-marketplace',
    status: 'warning',
    ip: 'localhost'
  },
  {
    id: 'log-997',
    timestamp: '2026-07-04 20:15',
    actor: 'n4bi10p',
    action: 'INVITE_TEAM_MEMBER',
    target: 'rushi@zexvro.io',
    status: 'success',
    ip: '198.162.4.29'
  }
];

export const mockSecurityKeys: SecurityKey[] = [
  {
    id: 'key-1',
    name: 'Main Enclave proving key',
    keyPrefix: 'zex_pk_live_8f...2e3a',
    created: '2026-07-05 18:34',
    lastUsed: '2026-07-05 21:40',
    status: 'active',
    owner: 'paris-29'
  },
  {
    id: 'key-2',
    name: 'Arbitrage Scanner Key',
    keyPrefix: 'zex_pk_live_ef...9d01',
    created: '2026-07-04 12:15',
    lastUsed: '2026-07-05 21:12',
    status: 'active',
    owner: 'Wraient'
  },
  {
    id: 'key-3',
    name: 'Depin Mesh Telemetry Sync',
    keyPrefix: 'zex_pk_test_bc...82ff',
    created: '2026-07-03 14:00',
    lastUsed: 'Never',
    status: 'active',
    owner: 'n4bi10p'
  },
  {
    id: 'key-4',
    name: 'Stale Sandbox Connector',
    keyPrefix: 'zex_pk_stale_aa...1122',
    created: '2026-06-20 09:00',
    lastUsed: '2026-06-25 10:20',
    status: 'revoked',
    owner: 'paris-29'
  }
];

// Recharts Analytics
export const requestAnalytics = [
  { name: '00:00', requests: 4200, errors: 22, latency: 45 },
  { name: '04:00', requests: 5100, errors: 41, latency: 48 },
  { name: '08:00', requests: 8400, errors: 85, latency: 52 },
  { name: '12:00', requests: 12500, errors: 120, latency: 68 },
  { name: '16:00', requests: 14200, errors: 154, latency: 70 },
  { name: '20:00', requests: 11200, errors: 82, latency: 54 },
  { name: '24:00', requests: 6800, errors: 30, latency: 46 }
];

export const serviceAdoptionData = [
  { name: 'ZK Pool', value: 45, color: '#FFFFFF' },
  { name: 'Transform Agent', value: 25, color: '#3B82F6' },
  { name: 'Trade Pipeline', value: 15, color: '#7C3AED' },
  { name: 'Agent Auth', value: 8, color: '#10B981' },
  { name: 'De-pin Mesh', value: 7, color: '#F59E0B' }
];

export const agentRunsData = [
  { name: 'July 1', transform: 40, deploy: 15, audit: 30 },
  { name: 'July 2', transform: 45, deploy: 18, audit: 35 },
  { name: 'July 3', transform: 50, deploy: 12, audit: 28 },
  { name: 'July 4', transform: 65, deploy: 24, audit: 45 },
  { name: 'July 5', transform: 88, deploy: 35, audit: 62 }
];

export const memberPerformanceData = [
  { name: 'paris-29', runs: 124, projects: 2, keys: 2 },
  { name: 'Wraient', runs: 98, projects: 1, keys: 1 },
  { name: 'n4bi10p', runs: 72, projects: 1, keys: 1 },
  { name: 'guardian-ai', runs: 280, projects: 4, keys: 0 }
];
